<?php 

$menu = array(
    array('text' => 'Fő oldal', 'link' => 'index.php'),
    array('text' => 'Információk', 'link' => 'info.php'),
    array('text' => 'Jelentkezés', 'link' => 'data.php'),
);
