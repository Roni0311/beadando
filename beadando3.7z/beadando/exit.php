<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <h1>Ez az exit</h1>
</head>
<body>
    <h2>A jelentkezés sikeres volt!</h2>
    <h3>Az alábbi gombra kattintva vissza kerül a kezdőoldalra.</h2>
<?php 
 echo '<form method="POST" action="data.php">
    <input type="submit"/>
  </form>';
?>
</body>
</html>