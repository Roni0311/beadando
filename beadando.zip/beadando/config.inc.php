<?php 

$menu = array(
    array('text' => 'Fő oldal', 'link' => '/beadando/main.php'),
    array('text' => 'Információk', 'link' => '/beadando/index.php'),
    array('text' => 'Jelentkezés', 'link' => '/beadando/data.php'),
);
